<?php include("includes/header.php");?>

    <div class="single-blog-wrapper section-padding-0-100">
        <!-- ##### Breadcumb Area Start ##### -->
        <div class="breadcumb-area bg-img" style="background-image: url(img/bg-img/b5.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="breadcumb-content text-center">
                            <h2>Suntime Travel</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ##### Breadcumb Area End ##### -->
        <div class="container" style="padding-top:2%;">
            <div class="row">
                <div class="col-12 col-lg-9">

                </div>
                    <?php include("includes/sidebar.php")?>
            </div>
        </div>
    
    </div>

<?php include("includes/footer.php")?>