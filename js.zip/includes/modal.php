


<div class="modal fade" id="quickview" tabindex="-1" role="dialog" aria-labelledby="quickview" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <button type="button" class="close btn" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div class="modal-body">
                        <div class="quickview_body">
                            <div class="container1">
                                <div class="row">
                                    <div class="col-12 col-lg-5">
                                        <div class="quickview_pro_img">
                                            <img src="img/product/gorras/3.jpg" alt="">
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-7">
                                        <div class="quickview_pro_des">
                                            <h4 class="title">Gorra Perú</h4>
                                            <div class="top_seller_product_rating mb-15">
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </div>
                                            <h5 class="price">S/.99.00 <span>S/.120.00</span></h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia expedita quibusdam aspernatur, sapiente consectetur accusantium perspiciatis praesentium eligendi, in fugiat?</p>
                                            <a href="single-product.php">Ver detalles completos</a>
                                        </div>
                                        <!-- Apply for whatsapp -->
                                        <form class="cart" method="post">
                                            <!-- <div class="quantity">
                                                <span class="qty-minus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) effect.value--;return false;"><i class="fa fa-minus" aria-hidden="true"></i></span>

                                                <input type="number" class="qty-text" id="qty" step="1" min="1" max="12" name="quantity" value="1">

                                                <span class="qty-plus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty )) effect.value++;return false;"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                            </div> -->
                                            <a class="cart-submit" href="https://wa.me/51923718170?text=%20https://www.linio.com.pe/p/reloj-ana-logo-swiss-militaire-490-29-hombre-n13jj7%20I'm%20interested%20in%20your%20product%20for%20sale"><i class="fa fa-whatsapp"></i>  Solicitar Ahora</a>
                                            <!-- Shared to facebook -->
                                            <div class="fb-share-button" style="padding:0 1%">
                                            <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Fwww.linio.com.pe%2Fp%2Freloj-ana-logo-swiss-militaire-490-29-hombre-n13jj7&layout=button&size=large&mobile_iframe=true&appId=630445934016844&width=99&height=34" width="99" height="34" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                                            </div>
                                            <!--  Test product -->
                                            <div class="modal_pro_test">
                                                <a href="·" target="_blank"><i class="fa fa-external-link"></i></a>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

